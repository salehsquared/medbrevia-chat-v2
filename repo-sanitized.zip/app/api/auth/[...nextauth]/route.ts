// app/api/auth/[...nextauth]/route.ts (chat app)
export { GET, POST } from '@/lib/auth/auth';