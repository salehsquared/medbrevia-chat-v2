// middleware.ts (chat app)
import {NextResponse} from 'next/server';
import {getToken} from 'next-auth/jwt';

const CANON_HOST = 'chat.medbrevia.com';

// Protect everything except static bits; tweak as needed
export const config = {
    matcher: ['/((?!api|_next/static|_next/image|assets|favicon.ico).*)'],
};

export async function middleware(req: any) {
    const url = new URL(req.url);

    // Canonicalize only in production
    if (process.env.NODE_ENV === 'production' && url.hostname !== CANON_HOST) {
        url.hostname = CANON_HOST;
        return NextResponse.redirect(url);
    }

    // --- Dev bypass: let localhost & .local run without auth ---
    if (process.env.NODE_ENV !== 'production' || url.hostname === 'localhost' || /\.local$/.test(url.hostname)) {
        return NextResponse.next();
    }

    // (Optional) allow public pages if you add any
    // if (url.pathname.startsWith('/public')) return NextResponse.next();

    // Require auth (reads the shared cookie set by medbrevia.com)
    const secret = process.env.AUTH_SECRET ?? process.env.NEXTAUTH_SECRET ?? '';
    const token = await getToken({req, secret});

    if (!token?.sub) {
        const loginUrl = new URL('https://medbrevia.com/account/login');
        loginUrl.searchParams.set('callbackUrl', url.toString());
        return NextResponse.redirect(loginUrl);
    }

    return NextResponse.next();
}