// lib/auth/auth.ts
import NextAuth from 'next-auth';
import CredentialsProvider from 'next-auth/providers/credentials';

/**
 * Minimal NextAuth config for chat.medbrevia.com:
 * - No DB adapter (not needed for JWT verification).
 * - No real providers (Credentials returns null) so users can't log in *here*.
 * - Reads the shared session cookie issued by medbrevia.com.
 */
export const {
    handlers: {GET, POST},
    auth,
} = NextAuth({
    providers: [
        CredentialsProvider({
            name: 'PassThrough',
            credentials: {},
            // Always return null so login never happens on chat.* (we redirect to medbrevia.com instead)
            async authorize() {
                return null;
            },
        }),
    ],

    // The key part: use the same cookie name & domain as the main site (prod only).
    cookies: {
        sessionToken: {
            name: '__Secure-authjs.session-token', // keep identical across apps
            options: {
                httpOnly: true,
                sameSite: 'lax',
                path: '/',
                secure: true,
                ...(process.env.NODE_ENV === 'production' ? {domain: '.medbrevia.com'} : {}),
            },
        },
    },

    // If anything in chat tries to show a sign-in page, redirect to the main site.
    pages: {signIn: 'https://medbrevia.com/account/login'},

    session: {strategy: 'jwt', maxAge: 12 * 60 * 60},
    jwt: {maxAge: 12 * 60 * 60, updateAge: 15 * 60},

    trustHost: true,
    secret: process.env.AUTH_SECRET ?? process.env.NEXTAUTH_SECRET,
});